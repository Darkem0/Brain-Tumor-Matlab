close all; clear; clc;
%% Verilerin Yüklenmesi
cd ..\a_Data\i_ML
load("Data.mat","PDK_cNet","PDK_Ensemble","PDK_SVMs");
cd ..\..\b_Kod\

%% Tablo Çekme

[Satir Sutun] = size(PDK_cNet);
a=0;
for i=1:Satir
    a=a+1;
    Tablo(a,:)=[PDK_cNet{i,1}(:,2)'];
    a=a+1;
    Tablo(a,:)=[PDK_Ensemble{i,1}(:,2)'];
    a=a+1;
    Tablo(a,:)=[PDK_SVMs{i,1}(:,2)'];
end

%% Kayıt
cd ..\a_Data\j_Tablo
save("Data.mat",'-v7.3');
cd ..\..\b_Kod