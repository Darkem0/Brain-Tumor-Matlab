%% Görüntü kanallarının ayrıştırılması
close all; clear; clc;
cd ..\a_Data\j_Tablo
load("Data.mat");
cd ..\..\b_Kod\

%% Spider Grafik Çıkarma
% Klasöre Giriş
cd Spider

%% Kodlama
% Toplamda 20 tane görüntü olacak. 5*4
Tablo(:,1)=Tablo(:,1)/100;

%% 1 i değeri 1-4-7 şekilde artar.
figure;
i=28;
P=Tablo(i:i+2,:);
S1 = spider_plot_class(P);
S1.FillOption = {'on', 'on', 'off'};
S1.FillTransparency = [0.2, 0.1, 0.1];
S1.AxesInterval = 2;
S1.LegendLabels = {'CNet', 'EDT', 'SVMs'};
S1.AxesLimits = [0.7,0.7,0.7,0.7,0.7,0.7; 1,1,1,1,1,1]; % [min axes limits; max axes limits]
S1.LabelFontSize = 10;
title('Level 10 - Number of Feature: 150',...
          'FontSize', 14);

%% 4 i değeri 1-4-7 şekilde artar.
figure;
i=52;
P=Tablo(i:i+2,:);
S2 = spider_plot_class(P);
S2.FillOption = {'on', 'on', 'off'};
S2.FillTransparency = [0.2, 0.1, 0.1];
S2.AxesInterval = 2;
S2.LegendLabels = {'CNet', 'EDT', 'SVMs'};
S2.AxesLimits = [0.7,0.7,0.7,0.7,0.7,0.7; 1,1,1,1,1,1]; % [min axes limits; max axes limits]
title('Level 18 - Number of Feature: 270',...
          'FontSize', 14);
% %% 7 i değeri 1-4-7 şekilde artar.
% figure;
% i=7;
% P=Tablo(i:i+2,:);
% S3 = spider_plot_class(P);
% 
% %% 7 i değeri 1-4-7 şekilde artar.
% figure;
% i=10;
% P=Tablo(i:i+2,:);
% S4 = spider_plot_class(P);
% 
% %% 7 i değeri 1-4-7 şekilde artar.
% figure;
% i=13;
% P=Tablo(i:i+2,:);
% S5 = spider_plot_class(P);

%% Eksenlerin İsimlendirilmesi
S1.AxesLabels = {'Acc', 'Sen', 'Spe', 'FM', 'Kappa', 'AUC'};
S2.AxesLabels = {'Acc', 'Sen', 'Spe', 'FM', 'Kappa', 'AUC'};
% S3.AxesLabels = {'Acc', 'Sen', 'Spe', 'FM', 'Kappa', 'AUC'};
% S4.AxesLabels = {'Acc', 'Sen', 'Spe', 'FM', 'Kappa', 'AUC'};
% S5.AxesLabels = {'Acc', 'Sen', 'Spe', 'FM', 'Kappa', 'AUC'};
% S6.AxesLabels = {'Acc', 'Sen', 'Spe', 'FM', 'Kappa', 'AUC'};
% S7.AxesLabels = {'Acc', 'Sen', 'Spe', 'FM', 'Kappa', 'AUC'};
% S8.AxesLabels = {'Acc', 'Sen', 'Spe', 'FM', 'Kappa', 'AUC'};
% S9.AxesLabels = {'Acc', 'Sen', 'Spe', 'FM', 'Kappa', 'AUC'};
% S10.AxesLabels = {'Acc', 'Sen', 'Spe', 'FM', 'Kappa', 'AUC'};
% S11.AxesLabels = {'Acc', 'Sen', 'Spe', 'FM', 'Kappa', 'AUC'};
% S12.AxesLabels = {'Acc', 'Sen', 'Spe', 'FM', 'Kappa', 'AUC'};
% S13.AxesLabels = {'Acc', 'Sen', 'Spe', 'FM', 'Kappa', 'AUC'};
% S14.AxesLabels = {'Acc', 'Sen', 'Spe', 'FM', 'Kappa', 'AUC'};
% S15.AxesLabels = {'Acc', 'Sen', 'Spe', 'FM', 'Kappa', 'AUC'};
% S16.AxesLabels = {'Acc', 'Sen', 'Spe', 'FM', 'Kappa', 'AUC'};
% S17.AxesLabels = {'Acc', 'Sen', 'Spe', 'FM', 'Kappa', 'AUC'};
% S18.AxesLabels = {'Acc', 'Sen', 'Spe', 'FM', 'Kappa', 'AUC'};
% S19.AxesLabels = {'Acc', 'Sen', 'Spe', 'FM', 'Kappa', 'AUC'};
% S20.AxesLabels = {'Acc', 'Sen', 'Spe', 'FM', 'Kappa', 'AUC'};

%% Tiled layout
% S1.tiledlayout(1, 2);

% Next tiles
% S1.nexttile(S1);
% S1.nexttile(S2);
% S1.nexttile(S3);
% S1.nexttile(S4);
% S1.nexttile(S5);

%% Tiled layout settings
% S1.TiledLayoutHandle.TileSpacing = 'none';
% S1.TiledLayoutHandle.Padding = 'compact';
% title(S1.TiledLayoutHandle, "Level 10 - Number of Feature: 150");
% title(S2.TiledLayoutHandle, "Level 18 - Number of Feature: 270");

%% 
% S1.tiledlegend('FontSize', 8);



% D1 = [5 3 9 1 2];
% D2 = [5 8 7 2 9];
% D3 = [8 2 1 4 6];
% P = [D1; D2; D3];
% if exist('s', 'var')
%   delete(s);
% end
% s = spider_plot_class(P);
% s.AxesLabels = {'Acc', 'Sen', 'Spe', 'FM', 'Kappa', 'AUC'};
% s.AxesInterval = 2;
% s.FillOption = {'on', 'on', 'off'};
% s.FillTransparency = [0.2, 0.1, 0.1];
pause(1)
% Geri Çıkma
% cd ..
%% Silme
% clearvars -except Maskeli_Matris Etiket

%% Kayıt
cd ..\..\a_Data\l_Spider
% save("Data.mat",'-v7.3');
cd ..\..\b_Kod