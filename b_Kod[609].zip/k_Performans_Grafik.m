%% Görüntü kanallarının ayrıştırılması
close all; clear; clc;
cd ..\a_Data\j_Tablo
load("Data.mat","Tablo");
cd ..\..\b_Kod\

%% Verilerin hazırlanması
X=[15, 30, 45, 60, 75, 90, 105, 120, 135, 150, 165, 180, 195, 210, ...
    225, 240, 255, 270, 285, 300]';

%% Her grafik için verinin çekilmesi
%% Sabit parametreler
L=size(Tablo,1)/3;
Y1 = [];
Y2 = [];
Y3 = [];
B1 = 1; % Başlangıç Y1 için
B2 = 2; % Başlangıç Y2 için
B3 = 3; % Başlangıç Y3 için
for k=1:L
    Y1=[Y1; Tablo(B1,:)];
    Y2=[Y2; Tablo(B2,:)];
    Y3=[Y3; Tablo(B3,:)];
    B1=B1+3;
    B2=B2+3;
    B3=B3+3;
end

%% Grafiklerin Hazırlanması
figure('Renderer', 'painters', 'Position', [10 10 1500 900])

%% Accuracy
i=1;% Sürun numarasını ifade ederi
subplot(3,2,i);
plot(X,Y1(:,i),X,Y2(:,i),X,Y3(:,i),'LineWidth',2);

xlim([15 300]);
xticks(X)

% xticks('15 30 45 60  75  90  105  120  135  150  165  180  195  210  ...
%     225  240  255  270  285  300');

grid minor;
ax=gca; % Get handle to current axes.
ax.GridAlpha = 0.6;  % Make grid lines less transparent.
ax.GridColor = [0.12, 0.7, 0.2]; % Dark Green.

set(gca,'FontWeight','bold','FontSize',20,'FontName','Times New Roman');
% legend('CNet','EDT','SVMs','Position', ...
%     [0.473555556807253 0.291246525956419 0.0759999987483025 ...
%     0.103990323562287]);
legend('CNet','EDT','SVMs','Position', ...
    [0.913996212747061 0.828407421063026 0.0759999987483023 0.0955555528733465]);
xlabel('Number of Features','FontWeight','bold','FontSize',20,...
'FontName','Times New Roman');
ylabel('Accuracy','FontWeight','bold','FontSize',20,...
'FontName','Times New Roman');

% title(['No filter'],'FontWeight','bold','FontSize',20,...
% 'FontName','Times New Roman');

%% Sensitivity
i=2;% Sürun numarasını ifade ederi
subplot(3,2,i);
plot(X,Y1(:,i),X,Y2(:,i),X,Y3(:,i),'LineWidth',2);

xlim([15 300]);
xticks(X)


grid minor;
ax=gca; % Get handle to current axes.
ax.GridAlpha = 0.6;  % Make grid lines less transparent.
ax.GridColor = [0.12, 0.7, 0.2]; % Dark Green.
 
set(gca,'FontWeight','bold','FontSize',20,'FontName','Times New Roman');
% legend('CNet','EDT','SVMs','Location','northeast');

xlabel('Number of Features','FontWeight','bold','FontSize',20,...
'FontName','Times New Roman');
ylabel('Sensitivity','FontWeight','bold','FontSize',20,...
'FontName','Times New Roman');

%% Specificity
i=3;% Sürun numarasını ifade ederi
subplot(3,2,i);
plot(X,Y1(:,i),X,Y2(:,i),X,Y3(:,i),'LineWidth',2);

xlim([15 300]);
xticks(X)


grid minor;
ax=gca; % Get handle to current axes.
ax.GridAlpha = 0.6;  % Make grid lines less transparent.
ax.GridColor = [0.12, 0.7, 0.2]; % Dark Green.

set(gca,'FontWeight','bold','FontSize',20,'FontName','Times New Roman');
% legend('CNet','EDT','SVMs','Location','northeast');

xlabel('Number of Features','FontWeight','bold','FontSize',20,...
'FontName','Times New Roman');
ylabel('Specificity','FontWeight','bold','FontSize',20,...
'FontName','Times New Roman');

%% F-Measurement
i=4;% Sürun numarasını ifade ederi
subplot(3,2,i);
plot(X,Y1(:,i),X,Y2(:,i),X,Y3(:,i),'LineWidth',2);

xlim([15 300]);
xticks(X)


grid minor;
ax=gca; % Get handle to current axes.
ax.GridAlpha = 0.6;  % Make grid lines less transparent.
ax.GridColor = [0.12, 0.7, 0.2]; % Dark Green.

set(gca,'FontWeight','bold','FontSize',20,'FontName','Times New Roman');
% legend('CNet','EDT','SVMs','Location','northeast');

xlabel('Number of Features','FontWeight','bold','FontSize',20,...
'FontName','Times New Roman');
ylabel('F-Measurement','FontWeight','bold','FontSize',20,...
'FontName','Times New Roman');

%% Kappa
i=5;% Sürun numarasını ifade ederi
subplot(3,2,i);
plot(X,Y1(:,i),X,Y2(:,i),X,Y3(:,i),'LineWidth',2);

xlim([15 300]);
xticks(X)


grid minor;
ax=gca; % Get handle to current axes.
ax.GridAlpha = 0.6;  % Make grid lines less transparent.
ax.GridColor = [0.12, 0.7, 0.2]; % Dark Green.

set(gca,'FontWeight','bold','FontSize',20,'FontName','Times New Roman');
% legend('CNet','EDT','SVMs','Location','northeast');

xlabel('Number of Features','FontWeight','bold','FontSize',20,...
'FontName','Times New Roman');
ylabel('Kappa','FontWeight','bold','FontSize',20,...
'FontName','Times New Roman');

%% AUC
i=6;% Sürun numarasını ifade ederi
subplot(3,2,i);
plot(X,Y1(:,i),X,Y2(:,i),X,Y3(:,i),'LineWidth',2);

xlim([15 300]);
xticks(X)


grid minor;
ax=gca; % Get handle to current axes.
ax.GridAlpha = 0.6;  % Make grid lines less transparent.
ax.GridColor = [0.12, 0.7, 0.2]; % Dark Green.

set(gca,'FontWeight','bold','FontSize',20,'FontName','Times New Roman');
% legend('CNet','EDT','SVMs','Location','northeast');

xlabel('Number of Features','FontWeight','bold','FontSize',20,...
'FontName','Times New Roman');
ylabel('AUC','FontWeight','bold','FontSize',20,...
'FontName','Times New Roman');



%% Kayıt
cd ..\a_Data\m_Performans
% save("Data.mat",'-v7.3');
cd ..\..\b_Kod