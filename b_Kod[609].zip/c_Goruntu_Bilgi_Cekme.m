%% Görüntü kanallarının ayrıştırılması
close all; clear; clc;
cd ..\a_Data\c_Filtreli
load Data
cd ..\..\b_Kod\
%% Maske Çekme
Maske = Goruntu(:,1);

%% Goruntulerin Çekilmesi
L_G=length(Etiket);
for i=1:L_G
    Matris{i,1}=im2double(Goruntu{i,2}(:,:,1));
    Matris{i,2}=im2double(Goruntu{i,2}(:,:,2));
    Matris{i,3}=im2double(Goruntu{i,2}(:,:,3));

    Matris{i,4}=im2double(Goruntu{i,3}(:,:,1));
    Matris{i,5}=im2double(Goruntu{i,3}(:,:,2));
    Matris{i,6}=im2double(Goruntu{i,3}(:,:,3));

    Matris{i,7}=im2double(Goruntu{i,4}(:,:,1));
    Matris{i,8}=im2double(Goruntu{i,4}(:,:,2));
    Matris{i,9}=im2double(Goruntu{i,4}(:,:,3));

    Matris{i,10}=im2double(Goruntu{i,5}(:,:,1));
    Matris{i,11}=im2double(Goruntu{i,5}(:,:,2));
    Matris{i,12}=im2double(Goruntu{i,5}(:,:,3));
end
% for i=1:12
% figure;
% imshow(Matris{1,i});
% end
%% Silme
clearvars -except Matris Etiket Maske

%% Kayıt
cd ..\a_Data\d_Matris
save("Data.mat",'-v7.3');
cd ..\..\b_Kod