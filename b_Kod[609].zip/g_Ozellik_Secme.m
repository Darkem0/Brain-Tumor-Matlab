%% Görüntü kanallarının ayrıştırılması
close all; clear; clc;
cd ..\a_Data\g_Ozellik_Birlestir
load Data
cd ..\..\b_Kod\

%% Özellik Seçme
[S_O]=FSY_Eta(Ozellikler);
L=length(S_O);
for i=1:L
    D_S_O{i,1} = veri_dengeleme(S_O{i,1});
    D_S_O{i,2} = S_O{i,2};
    D_S_O{i,3} = S_O{i,3};
end

%% Denem Verisi
Data = D_S_O{20,1};

%% Silme
clearvars -except S_O D_S_O

%% Kayıt
cd ..\a_Data\h_Ozellik_Secme
save("Data.mat",'-v7.3');
cd ..\..\b_Kod