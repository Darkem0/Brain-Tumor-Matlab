function [PDK Cikis_Cevap Cikis]=cNet(Ozellikler)
%% S�n�fland�rma parametrelerinin tespit edilmesi
% close all ; clear all ; clc ;
% %% Kay�tlar�n y�klenmesi
% %% Dengeli
% cd .. ; cd a_Data\b_P_Score ;
% load P_Score ;
% cd ..\.. ; cd b_Kod ;
%%

%% Verilerin Al�nmas�
[Egitim, Egitimc, Test, Testc] = Orneklem(Ozellikler) ;
%% A�ac�n olu�turulmas�
% a=0;
% while a<1
% create classification tree
tic
%% SVMs a��n�n e�itilmesi
% SVMstruct = fitcsvm(...
%     Egitim, ...
%     Egitimc, ...
%     'KernelFunction', 'polynomial', ...
%     'PolynomialOrder', 2, ...
%     'KernelScale', 'auto', ...
%     'BoxConstraint', 1, ...
%     'Standardize', true, ...
%     'ClassNames', [1; 2]);
%%
SVMstruct = fitcnet(Egitim,Egitimc, ...
    "OptimizeHyperparameters","all");

%%
Time_C=toc;
% %% G�rselle�tirme
% view(ctree) % text description
% view(ctree,'mode','graph') % graphic description

%% A��n Test Edilmesi
Egitims = predict(SVMstruct,Egitim);
Tests = predict(SVMstruct,Test);

%% Performans Kriterlerinin Hesaplanmas�
    PDK(:,1) = Performans(Egitimc,Egitims);
    PDK(:,2) = Performans(Testc,Tests);
%     E_R = PDK(5,1);
%     T_R = PDK(5,2);
%     clearvars PDK
%     Parametreler=[E_R T_R];
    Cikis{1,1}=Egitims; % Simulasyon Cevaplar�
    Cikis{1,2}=Tests; % Simulasyon Cevaplar�
    Cikis_Cevap{1,1}=Egitimc; % Ger�ek ��k��lar
    Cikis_Cevap{1,2}=Testc; % Ger�ek ��k��lar
end