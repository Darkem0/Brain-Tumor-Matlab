close all; clear; clc;
%% Verilerin Yüklenmesi
cd ..; cd a_Data/g_Ozellik_Secme
load('Data.mat');
cd ../..; cd b_Kod;

%% Ensemble Sınıflandırma
for i=1:11
    [PDK{i,1} Cikis_Cevap{i,1} Cikis{i,1}] = ET_Optimizasyon(S_O{i,1});
end
%% Kayıt
cd ..; cd a_Data/h_Ensemble
save('Data.mat','-v7.3');
cd ..\..\b_Kod