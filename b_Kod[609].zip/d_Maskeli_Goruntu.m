%% Görüntü kanallarının ayrıştırılması
close all; clear; clc;
cd ..\a_Data\d_Matris
load Data
cd ..\..\b_Kod\

%% Maskeye göre çekme
L_G=length(Etiket);
a=1;
for i=1:L_G
    Maskeli_Matris{i,a} = Maske_Cekme(Matris{i,a},Maske{i,1});
    Maskeli_Matris{i,a+1} = Maske_Cekme(Matris{i,a+1},Maske{i,1});
    Maskeli_Matris{i,a+2} = Maske_Cekme(Matris{i,a+2},Maske{i,1});

    Maskeli_Matris{i,a+3} = Maske_Cekme(Matris{i,a+3},Maske{i,1});
    Maskeli_Matris{i,a+4} = Maske_Cekme(Matris{i,a+4},Maske{i,1});
    Maskeli_Matris{i,a+5} = Maske_Cekme(Matris{i,a+5},Maske{i,1});

    Maskeli_Matris{i,a+6} = Maske_Cekme(Matris{i,a+6},Maske{i,1});
    Maskeli_Matris{i,a+7} = Maske_Cekme(Matris{i,a+7},Maske{i,1});
    Maskeli_Matris{i,a+8} = Maske_Cekme(Matris{i,a+8},Maske{i,1});

    Maskeli_Matris{i,a+9} = Maske_Cekme(Matris{i,a+9},Maske{i,1});
    Maskeli_Matris{i,a+10} = Maske_Cekme(Matris{i,a+10},Maske{i,1});
    Maskeli_Matris{i,a+11} = Maske_Cekme(Matris{i,a+11},Maske{i,1});
end

%% Silme
clearvars -except Maskeli_Matris Etiket

%% Kayıt
cd ..\a_Data\e_Maskeli
save("Data.mat",'-v7.3');
cd ..\..\b_Kod