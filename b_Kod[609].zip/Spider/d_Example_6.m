close all; clear; clc;%% Example 9: Spider plot with shaded area around axes.

% Initialize data points
D1 = [5 3 9 1 2];
D2 = [5 8 7 2 9];
D3 = [8 2 1 4 6];
P = [D1; D2; D3];

% Delete variable in workspace if exists
if exist('s', 'var')
    delete(s);
end

% Spider plot
s = spider_plot_class(P);
s.AxesShaded = 'on';
s.AxesShadedLimits = [5.5, 4, 3, 2, 4; 7, 6.5, 6, 3.5, 6]; % [min axes limits; max axes limits]