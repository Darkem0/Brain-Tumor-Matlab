close all; clear; clc;
% Example 2: Manually setting the axes limits. All non-specified, optional arguments are set to their default values.

% Initialize data points
D1 = [5 3 9 1 2 5]/10;
D2 = [5 8 7 2 9 6]/10;
D3 = [8 2 1 4 6 7]/10;
P = [D1; D2; D3];

% Delete variable in workspace if exists
if exist('s', 'var')
    delete(s);
end

% Spider plot
s = spider_plot_class(P);

% Spider plot properties
% s.AxesLimits = [1, 2, 1, 1, 1; 10, 8, 9, 5, 10]; % [min axes limits; max axes limits]
% s.AxesPrecision = [0, 1, 1, 1, 1];