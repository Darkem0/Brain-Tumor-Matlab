close all; clear; clc;
% Example 2: Manually setting the axes limits. All non-specified, optional arguments are set to their default values.

% Example 3: Set fill option on. The fill transparency can be adjusted.

% Initialize data points
D1 = [5 3 9 1 2];
D2 = [5 8 7 2 9];
D3 = [8 2 1 4 6];
D4 = [8 2 1 4 6]-1;
P = [D1; D2; D3; D4];

% Delete variable in workspace if exists
if exist('s', 'var')
    delete(s);
end

% Spider plot
s = spider_plot_class(P);

% Spider plot properties
% s.AxesLabels = {'S1', 'S2', 'S3', 'S4', 'S5'};
% s.AxesInterval = 2;
% s.FillOption = {'on', 'on', 'off'};
% s.FillTransparency = [0.2, 0.1, 0.1];

figure
  D1 = [5 3 9 1 2];
  D2 = [5 8 7 2 9];
  D3 = [8 2 1 4 6];
  P = [D1; D2; D3];
  if exist('s', 'var')
      delete(s);
  end
  s = spider_plot_class(P);
  s.AxesLabels = {'S1', 'S2', 'S3', 'S4', 'S5'};
  s.AxesInterval = 2;
  s.FillOption = {'on', 'on', 'off'};
  s.FillTransparency = [0.2, 0.1, 0.1];