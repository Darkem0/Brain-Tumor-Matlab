close all; clear; clc;
% Example 1: Minimal number of arguments. All non-specified, optional arguments are set to their default values. Axes labels and limits are automatically generated and set.

% Initialize data points
D1 = [0.6 0.7 0.8 0.85 0.9];
D2 = [0.65 0.75 0.85 0.8 0.85];
D3 = [0.66 0.67 0.78 0.75 0.8];
P = [D1; D2; D3];

% Delete variable in workspace if exists
if exist('s', 'var')
    delete(s);
end

% Spider plot
s = spider_plot_class(P);

% Legend properties
s.LegendLabels = {'D1', 'D2', 'D3'};
s.LegendHandle.Location = 'northeastoutside';