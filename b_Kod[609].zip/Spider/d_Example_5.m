close all; clear; clc;
% Example 8: Spider plot with values only on data points.

% Initialize data points
close all;
D1 = [1 3 4 1 2];
D2 = [5 8 7 5 9];
P = [D1; D2];

% Delete variable in workspace if exists
if exist('s', 'var')
    delete(s);
end

% Spider plot
s = spider_plot_class(P);
s.AxesLimits = [1, 1, 1, 1, 1; 10, 10, 10, 10, 10];
s.AxesDisplay = 'data';
s.AxesLabelsOffset = 0.2;
s.AxesDataOffset = 0.1;
s.AxesFontColor = [0, 0, 1; 1, 0, 0];

% Legend properties
s.LegendLabels = {'D1', 'D2'};
s.LegendHandle.Location = 'northeastoutside';

