%% Görüntü kanallarının ayrıştırılması
close all; clear; clc;
cd ..\a_Data\b_Matlab
load("Data.mat","G");
cd ..\..\b_Kod\

%% Görüntülerin Belirlenmesi

%% Ham Görüntünün Alınması
cd ..\a_Data\a_Ham\Abdullah_Ekinci\
[Ham_H13, ~, ImageAlpha_H13] = imread('H13_Ham.png');
% image(Ham_H13, 'AlphaData', ImageAlpha_H13)
% imshow(Ham_H13); % Görüntü imshow ile gösterilecek
cd ..\..\..\b_Kod\

%% Segmentasyonlu Görüntünün Alınması
% close all;
i=5; % i=5 Abullah Ekinci H13'e karşılık geliyor. Onu kullanalım.
figure
imshow(G{i,1});
figure
imshow(G{i,3});
% [YourImage, ~, ImageAlpha] = imread('H2.png');
% image(YourImage, 'AlphaData', ImageAlpha)
figure
image(G{i,1}, 'AlphaData', G{i,3})

%% Filtreli
cd ..\a_Data\c_Filtreli
load Data
cd ..\..\b_Kod\

% Goruntu{i,3} = imfilter(G{i,1},H,'replicate'); % Average
% Goruntu{i,4} = rgb2hsv(Goruntu{i,2}); % Filtresiz HSV
% Goruntu{i,5} = rgb2hsv(Goruntu{i,3}); % Filtreli HSV
figure
imshow(Goruntu{i,3});
figure
imshow(Goruntu{i,4});
figure
imshow(Goruntu{i,5});

%% Matris GÖrüntü
cd ..\a_Data\d_Matris
load Data
cd ..\..\b_Kod\

for j=1:12
    figure
    imshow(Matris{i,j});
%     imshow(Maskeli_Matris{i,j});
% ilk 3 tane orjinal GÖrüntü RGB kanalları
% 4-6 % Average
% 7-9 % Filtresiz HSV
% 10-12 % Filtreli HSV
end

%% Silme
% clearvars -except Maskeli_Matris Etiket

%% Kayıt
cd ..\a_Data\k_Surec
% save("Data.mat",'-v7.3');
cd ..\..\b_Kod