%% Görüntü kanallarının ayrıştırılması
close all; clear; clc;
cd ..\a_Data\e_Maskeli
load Data
cd ..\..\b_Kod\

%% Özellik Çıkarma
L_M=length(Etiket);
for i=1:L_M
    for j=1:size(Maskeli_Matris,2)
        Ozellik{i,j} = Ozellik_Cikarimi(Maskeli_Matris{i,j});
    end
end

%% Silme
clearvars -except Ozellik Etiket

%% Kayıt
cd ..\a_Data\f_Ozellik_Cikarma
save("Data.mat",'-v7.3');
cd ..\..\b_Kod