close all; clear; clc;
%% Verilerin Yüklenmesi
cd ..\a_Data\h_Ozellik_Secme
load Data
cd ..\..\b_Kod\

%% SVMs
L=length(S_O);
for i=1:L
    [PDK_SVMs{i,1} Cikis_Cevap_SVMs{i,1} Cikis_SVMs{i,1}]=SVMs(S_O{i,1});
    [PDK_cNet{i,1} Cikis_Cevap_cNet{i,1} Cikis_cNet{i,1}]=cNet(S_O{i,1});
    [PDK_Ensemble{i,1} Cikis_Cevap_Ensemble{i,1} Cikis_Ensemble{i,1}]=Ensemble(S_O{i,1});
end
%% Kayıt
cd ..\a_Data\i_ML
save("Data.mat",'-v7.3');
cd ..\..\b_Kod