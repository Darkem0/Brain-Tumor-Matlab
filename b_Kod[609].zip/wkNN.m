function [PDK Cikis_Cevap Cikis]=wkNN(Ozellikler)
%% Sýnýflandýrma parametrelerinin tespit edilmesi
% close all ; clear all ; clc ;
% %% Kayýtlarýn yüklenmesi
% %% Dengeli
% cd .. ; cd a_Data\b_P_Score ;
% load P_Score ;
% cd ..\.. ; cd b_Kod ;
%%

%% Verilerin Alýnmasý
[Egitim, Egitimc, Test, Testc] = Orneklem(Ozellikler) ;
%% Aðacýn oluþturulmasý
% a=0;
% while a<1
% create classification tree
tic
%% kNN Ağının Eğitilmesi
% SVMstruct = fitcknn(...
%     Egitim, ...
%     Egitimc, ...
%     'Distance', 'Euclidean', ...
%     'Exponent', [], ...
%     'NumNeighbors', 10, ...
%     'DistanceWeight', 'SquaredInverse', ...
%     'Standardize', true, ...
%     'ClassNames', [1; 2]);
%%
% SVMstruct = fitcknn(Egitim,Egitimc, ...
%     "OptimizeHyperparameters","none");

SVMstruct = fitctree(Egitim,Egitimc, ...
    "OptimizeHyperparameters","all");

%%
Time_C=toc;
% %% Görselleþtirme
% view(ctree) % text description
% view(ctree,'mode','graph') % graphic description

%% Aðýn Test Edilmesi
Egitims = predict(SVMstruct,Egitim);
Tests = predict(SVMstruct,Test);

%% Performans Kriterlerinin Hesaplanmasý
    PDK(:,1) = Performans(Egitimc,Egitims);
    PDK(:,2) = Performans(Testc,Tests);
%     E_R = PDK(5,1);
%     T_R = PDK(5,2);
%     clearvars PDK
%     Parametreler=[E_R T_R];
    Cikis{1,1}=Egitims; % Simulasyon Cevaplarý
    Cikis{1,2}=Tests; % Simulasyon Cevaplarý
    Cikis_Cevap{1,1}=Egitimc; % Gerçek Çýkýþlar
    Cikis_Cevap{1,2}=Testc; % Gerçek Çýkýþlar
end