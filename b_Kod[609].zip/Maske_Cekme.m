function Maskeli_Matris = Maske_Cekme(Data,M)
    %% Matris Çekme
%     Data = Matris{i,1};
%     M = Maske{i,1};
    a=0;
    [Sa Su]=size(M);
        for j=1:Sa*Su
            if M(j)>0
                a=a+1;
                Maskeli_Matris(a,1) = Data(j);
            end
        end
    end