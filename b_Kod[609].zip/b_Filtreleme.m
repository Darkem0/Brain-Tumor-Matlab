%% Veri Çekme
close all; clear; clc;
cd ..\a_Data\b_Matlab
load Data
cd ..\..\b_Kod\
%% Sayısal Filtreleme
H = fspecial('average',3);
L_G=length(Etiket);
for i=1:L_G
    Goruntu{i,1}=G{i,3}; % Maske
    Goruntu{i,2}=G{i,1}; % Orjinal Goruntu
    Goruntu{i,3} = imfilter(G{i,1},H,'replicate'); % Average
    Goruntu{i,4} = rgb2hsv(Goruntu{i,2}); % Filtresiz HSV
    Goruntu{i,5} = rgb2hsv(Goruntu{i,3}); % Filtreli HSV
end

Ornek = Goruntu{i,3};
% image(Ornek(:,:,3))

%% Silme
clearvars -except Goruntu Etiket

%% Kayıt
cd ..\a_Data\c_Filtreli
save("Data.mat",'-v7.3');
cd ..\..\b_Kod