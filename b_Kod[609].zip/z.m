close all; clear; clc;
%% Verilerin Yüklenmesi
cd ..\a_Data\h_Ozellik_Secme
load Data
cd ..\..\b_Kod\

%% SVMs
L=length(S_O);
for i=L:L
    [PDK{i,1} Cikis_Cevap{i,1} Cikis{i,1}]=wkNN(S_O{i,1});
end
%% Kayıt
%% Kayıt
cd ..\a_Data\i_SVMs
save("Data.mat",'-v7.3');
cd ..\..\b_Kod