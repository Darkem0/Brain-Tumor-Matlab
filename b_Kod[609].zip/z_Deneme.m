close all; clear; clc;

% [img, map, alphachannel] = imread('H2.png');
% image(img, 'AlphaData', alphachannel);
% imshow(img)
% axis off
% set(gca,'Color','none')
% hold on
% imshow(alphachannel)

%% Çalışıyor. Gayet Güzel
% [YourImage, ~, ImageAlpha] = imread('H2.png');
% image(YourImage, 'AlphaData', ImageAlpha)

%% Çalışıyor.
% [RGBdata, map, alpha] = imread('H2.png', 'png');
% imshow(RGBdata)
% figure
% image(RGBdata, 'AlphaData', alpha)